/**
 * Representa el tablero de celdas del juego SilkRoad.
 * Cada celda puede mostrar una parte del camino, una tienda o un robot.
 * 
 * Sara González - Lizeth Niviay 
 */
public class Board {
    private int size;           
    private Cell[][] cells;     

    public Board(int size) {
        this.size = size;
        this.cells = new Cell[size][size];

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                int x = col * Cell.SIZE;
                int y = row * Cell.SIZE;
                cells[row][col] = new Cell("white", false, x, y);
            }
        }
    }

    public void makeVisible() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cells[i][j].makeVisible();
            }
        }
    }

    public void makeInvisible() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cells[i][j].makeInvisible();
            }
        }
    }

    public Cell getCell(int row, int col) {
        if (row >= 0 && row < size && col >= 0 && col < size) {
            return cells[row][col];
        }
        return null;
    }

    public int getSize() {
        return size;
    }
}
