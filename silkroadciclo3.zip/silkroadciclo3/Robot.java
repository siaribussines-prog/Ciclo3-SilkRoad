import java.util.List;
import java.util.ArrayList;
/**
 * La clase contiene los metodos de robot de SkillRoad
 * 
 * Sara G - Lizeth Niviay
 */
public class Robot {
    private int initialLocation;
    private int currentLocation;
    private Circle head;
    private Rectangle neck;
    private Rectangle body;
    private Rectangle lefthand;
    private Rectangle righthand;
    private Rectangle leftleg;
    private Rectangle rightleg;
    //ciclo 2//
    private List<Integer> profitsPerMove;  // ganancias en cada movimiento
    
    public Robot(int location) {
        //ciclo 2//
        this.initialLocation = location;
        this.currentLocation = location;
        this.profitsPerMove = new ArrayList<>();   // inicializar la lista
        head = new Circle();
        head.changeSize(50);
        head.moveHorizontal(98);
        head.moveVertical(90);
        neck = new Rectangle();
        neck.changeSize(15,10);
        neck.moveHorizontal(118);
        neck.moveVertical(140);
        body = new Rectangle();
        body.changeSize(50, 60);
        body.moveHorizontal(95);
        body.moveVertical(147);
        lefthand = new Rectangle();
        lefthand.changeSize(50, 10);
        lefthand.moveHorizontal(85);
        lefthand.moveVertical(155);
        righthand = new Rectangle();
        righthand.changeSize(50, 10);
        righthand.moveHorizontal(155);
        righthand.moveVertical(155);
        leftleg = new Rectangle();
        leftleg.changeSize(50, 10);
        leftleg.moveHorizontal(130);
        leftleg .moveVertical(180);
        rightleg = new Rectangle();
        rightleg.changeSize(50, 10);
        rightleg.moveHorizontal(110);
        rightleg .moveVertical(180);
        changeColor("blue");
    }
    
    public void changeColor(String color){
    head.changeColor(color);
    neck.changeColor(color);
    body.changeColor(color);
    lefthand.changeColor(color);
    righthand.changeColor(color);
    leftleg.changeColor(color);
    rightleg.changeColor(color);
    }
    
    public void graphicMove(int row, int col){
    head.moveHorizontal(98+250*col);
    head.moveVertical(90+250*row);
    neck.moveHorizontal(118+250*col);
    neck.moveVertical(140+250*row);
    body.moveHorizontal(95+250*col);
    body.moveVertical(147+250*row);
    lefthand.moveHorizontal(85+250*col);
    lefthand.moveVertical(155+250*row);
    righthand.moveHorizontal(155+250*col);
    righthand.moveVertical(155+250*row);
    leftleg.moveHorizontal(130+250*col);
    leftleg.moveVertical(180+250*row);
    rightleg.moveHorizontal(110+250*col);
    rightleg.moveVertical(180+250*row);
    }
    public void makeVisible() {
        head.makeVisible();
        neck.makeVisible();
        body.makeVisible();
        lefthand.makeVisible();
        righthand.makeVisible();
        leftleg.makeVisible();
        rightleg.makeVisible();
    }
    
    public void makeInvisible() {
        head.makeInvisible();
        neck.makeInvisible();
        body.makeInvisible();
        lefthand.makeInvisible();
        righthand.makeInvisible();
        leftleg.makeInvisible();
        rightleg.makeInvisible();
    }
    public int getLocation() { 
        return currentLocation; 
    }
    
    public int getInitialLocation() { 
        return initialLocation; 
    }

    public void reset() {
        this.currentLocation = initialLocation;
    }

    public void move(int meters) {
        currentLocation += meters;
    }
    
//Ciclo 2// aca se registran las ganancias

    public void addProfit(int profit) {
        profitsPerMove.add(profit);
    }

    public List<Integer> getProfitsPerMove() {
        return profitsPerMove;
    }
}














