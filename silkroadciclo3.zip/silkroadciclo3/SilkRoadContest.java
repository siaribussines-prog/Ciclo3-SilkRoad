public class SilkRoadContest {

    /**
     * Calcula la máxima utilidad diaria para cada día del evento.
     */
    public int[] solve(int[][] days) {
        int[] maximos = new int[days.length];

        for (int i = 0; i < days.length; i++) {
            int max = Integer.MIN_VALUE;
            for (int j = 0; j < days[i].length; j += 2) {
                int venta = days[i][j];
                int costo = days[i][j + 1];
                int utilidad = venta - costo;
                if (utilidad > max) {
                    max = utilidad;
                }
            }
            maximos[i] = max;
        }

        return maximos;
    }

    /**
     * Simula gráficamente la utilidad diaria.
     */
    public void simulate(int[][] days, boolean slow) {
        SilkRoad sr = new SilkRoad();
        int[] resultados = solve(days);

        System.out.println("Simulación de la maratón:");
        for (int i = 0; i < resultados.length; i++) {
            System.out.println("Día " + (i + 1) + " → Máxima utilidad: " + resultados[i]);
            if (slow) {
                try {
                    Thread.sleep(1000); // pausa de 1 segundo entre días
                } catch (InterruptedException e) {
                    // Ignorar
                }
            }
        }

        System.out.println("✅ Simulación finalizada.");
    }
}
