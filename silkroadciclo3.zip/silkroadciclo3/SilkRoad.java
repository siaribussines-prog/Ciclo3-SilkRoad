import java.util.*;
import javax.swing.JOptionPane;

/**
 * Clase que maneja las operaciones para el simulador de SilkRoad
 * Sara G
 */
public class SilkRoad {
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int length;
    private int profit;
    private boolean lastOperationOk;
    private Board board;
    private boolean showing;
    
    /** Constructor sin parámetros (por defecto) */
    public SilkRoad() {
        this(10); // crea un SilkRoad de longitud 10 por lo del ciclo 3
    }

    /**
     * Crea una ruta y un tablero de longitud length
     *
     * @param length tamaño de la ruta
     */
    public SilkRoad(int length) {
        if (length <= 0) {
            System.out.println("⚠️ Error: la longitud debe ser mayor a 0.");
            length = 1;
        } else {
            this.length = length;
        }

        this.length = 0;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.profit = 0;
        this.lastOperationOk = true;
        this.showing = false;

        double n = Math.sqrt(length);
        int z = (int) Math.ceil(n);
        board = new Board(z);
    }

    /** Muestra un mensaje de error solo si la simulación está visible. */
    private void error(String msg) {
        if (showing) {
            System.out.println("⚠️ " + msg);
        }
    }

    /** Grafica la ruta */
    public void makeVisible() {
        board.makeVisible();
        for (Store s : stores) {
            s.makeVisible();
        }
        for (Robot r : robots) {
            r.makeVisible();
        }
        this.showing = true;
    }

    /** Oculta la ruta */
    public void makeInvisible() {
        board.makeInvisible();
        for (Store s : stores) {
            s.makeInvisible();
        }
        for (Robot r : robots) {
            r.makeInvisible();
        }
        this.showing = false;
    }

    /** Intenta colocar una tienda en la ubicación dada. */
    public void placeStore(int location, int tenges) {
        if (location < 0 || location >= this.length) { // Validar que la ubicación esté dentro de la ruta
            lastOperationOk = false;
            error("Ubicación inválida para la tienda.");
            return;
        }

        for (Store s : stores) {
            if (s.getLocation() == location) {
                lastOperationOk = false;
                error("Ya existe una tienda en esa ubicación.");
                return;
            }
        }
        
        if (tenges <= 0) {
            lastOperationOk = false;
            error("El número de tenges debe ser mayor a 0.");
            return;
        }

        Store newstore = new Store(location, tenges);
        // Convierte ubicación a coordenadas gráficas
        int[] cords = positionToCoords(location, this.length);
        newstore.graphicMove(cords[0], cords[1]);
        newstore.changeColor(randomColor());
        stores.add(newstore);
        // Ordenar las tiendas (por ubicación)
        for (int i = 0; i < stores.size() - 1; i++) {
            for (int j = i + 1; j < stores.size(); j++) {
                if (stores.get(i).getLocation() > stores.get(j).getLocation()) {
                    Store temp = stores.get(i);
                    stores.set(i, stores.get(j));
                    stores.set(j, temp);
                }
            }
        }
    
        lastOperationOk = true;
    
        // Actualizar la visualización si está activa
        if (showing) {
            makeInvisible();
            makeVisible();
        }
    }

    /** Busca y elimina una tienda */
    public void removeStore(int location) {
        boolean removed = false;

        for (int i = 0; i < stores.size(); i++) {
            Store s = stores.get(i);
            if (s.getLocation() == location) {
                s.makeInvisible();
                stores.remove(i);
                removed = true;
                break;
            }
        }

        if (!removed) {
            error("No se encontró una tienda en la ubicación " + location + ".");
        }

        lastOperationOk = removed;
    }

    /** Reinicia las monedas en todas las tiendas. */
    public void resupplyStores() {
        for (Store s : stores) {
            s.reset();
        }
        lastOperationOk = true;
    }

    /** Intenta colocar un Robot en la ubicación dada. */
    public void placeRobot(int location) {
        if (location < 0 || location >= this.length) {
            lastOperationOk = false;
            error("Ubicación inválida para el robot.");
            return;
        }

        for (Robot r : robots) {
            if (r.getInitialLocation() == location) {
                lastOperationOk = false;
                error("Ya existe un robot en esa ubicación.");
                return;
            }
        }

        Robot newrobot = new Robot(location);
        int[] cords = positionToCoords(location, this.length);
        newrobot.graphicMove(cords[0], cords[1]);
        newrobot.changeColor(randomColor());
        robots.add(newrobot);
        robots.sort(Comparator.comparingInt(Robot::getLocation));

        lastOperationOk = true;
        if (showing) {
            makeInvisible();
            makeVisible();
        }
        System.out.println("Robot creado en posición " + location + ".");
    }

    /** Busca un Robot en la ubicación dada y lo elimina. (sin lambda) */
    public void removeRobot(int location) {
        boolean removed = false;

        for (int i = 0; i < robots.size(); i++) {
            Robot r = robots.get(i);
            if (r.getLocation() == location) {
                r.makeInvisible();
                robots.remove(i);
                removed = true;
                break;
            }
        }

        if (!removed) {
            error("No se encontró un robot en la ubicación " + location + ".");
        }

        lastOperationOk = removed;
    }

    /** Busca un Robot en la ubicación dada y lo mueve. */
    public void moveRobot(int location, int meters) {
        for (Robot r : robots) {
            if (r.getLocation() == location) {
                int finallocation = location + meters;

                if (finallocation >= length || finallocation < 0) {
                    lastOperationOk = false;
                    error("Movimiento inválido: el robot saldría de la ruta.");
                    return;
                }

                int[] cords = positionToCoords(finallocation, this.length);
                r.graphicMove(cords[0], cords[1]);
                r.move(meters);

                for (Store s : stores) {
                    if (s.getLocation() == r.getLocation() && s.getTenges() > 0) {
                        int collected = s.collect();
                        int distance = Math.abs(r.getInitialLocation() - r.getLocation());
                        int gain = collected - distance;
                        profit += Math.max(gain, 0);
                    }
                }
                lastOperationOk = true;
                return;
            }
        }

        lastOperationOk = false;
        error("No se encontró un robot en la ubicación " + location + ".");
    }

    /** Todos los Robots vuelven a su posición de origen. */
    public void returnRobots() {
        for (Robot r : robots) {
            int[] cords = positionToCoords(r.getInitialLocation(), this.length);
            r.graphicMove(cords[0], cords[1]);
            r.reset();
        }
        lastOperationOk = true;
    }

    /** Reabastece tiendas, retorna robots y reinicia el profit. */
    public void reboot() {
        resupplyStores();
        returnRobots();
        profit = 0;
        lastOperationOk = true;
    }

    /** Termina la simulación. */
    public void finish() {
        makeInvisible();
        System.exit(0);
    }

    /** Devuelve el profit acumulado. */
    public int profit() {
        return profit;
    }

    /** Lista de tiendas (ubicación, tenges). */
    public int[][] stores() {
        int[][] arr = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            arr[i][0] = stores.get(i).getLocation();
            arr[i][1] = stores.get(i).getTenges();
        }
        return arr;
    }

    /** Lista de robots (origen, ubicación actual). */
    public int[][] robots() {
        int[][] arr = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            arr[i][0] = robots.get(i).getInitialLocation();
            arr[i][1] = robots.get(i).getLocation();
        }
        return arr;
    }

    /** Indica si la última operación fue válida. */
    public boolean ok() {
        return lastOperationOk;
    }

    /** Convierte una ubicación a coordenadas en espiral cuadrada. */
    public int[] positionToCoords(int location, int length) {
        int n = (int) Math.ceil(Math.sqrt(length));
        int[][] board = new int[n][n];

        int[] dx = {0, 1, 0, -1};
        int[] dy = {1, 0, -1, 0};
        int dir = 0;

        int x = 0, y = 0;
        boolean[][] visited = new boolean[n][n];

        for (int k = 0; k < length; k++) {
            board[x][y] = k;
            if (k == location) {
                return new int[]{x, y};
            }
            visited[x][y] = true;

            int nx = x + dx[dir];
            int ny = y + dy[dir];
            if (nx < 0 || nx >= n || ny < 0 || ny >= n || visited[nx][ny]) {
                dir = (dir + 1) % 4;
                nx = x + dx[dir];
                ny = y + dy[dir];
            }
            x = nx;
            y = ny;
        }
        return null;
    }

    /** Genera un color válido y aleatorio. */
    public String randomColor() {
        String[] colors = {"yellow", "red", "blue", "green", "purple", "black", "pink", "orange"};
        Random random = new Random();
        int randomindx = random.nextInt(colors.length);
        return colors[randomindx];
    }

    /** Mueve todos los robots buscando maximizar ganancia */
    public void moveRobots() {
        for (Robot r : robots) {
            int bestGain = Integer.MIN_VALUE;
            int bestMove = 0;

            for (Store s : stores) {
                int distance = Math.abs(r.getLocation() - s.getLocation());
                int potentialGain = s.getTenges() - distance;
                if (potentialGain > bestGain) {
                    bestGain = potentialGain;
                    bestMove = s.getLocation() - r.getLocation();
                }
            }

            if (bestGain > 0 && bestMove != 0) {
                moveRobot(r.getLocation(), bestMove);
            }
        }
    }

    /** Consulta cuántas veces ha sido desocupada cada tienda */
    public int[][] emptiedStores() {
        int[][] arr = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            arr[i][0] = stores.get(i).getLocation();
            arr[i][1] = stores.get(i).getEmptiedCount();
        }
        return arr;
    }

    /** Consulta las ganancias por movimiento de cada robot */
    public int[][] profitPerMove() {
        int[][] arr = new int[robots.size()][];
        for (int i = 0; i < robots.size(); i++) {
            Robot r = robots.get(i);
            List<Integer> moves = r.getProfitsPerMove();
            arr[i] = new int[moves.size() + 1];
            arr[i][0] = r.getInitialLocation();
            for (int j = 0; j < moves.size(); j++) {
                arr[i][j + 1] = moves.get(j);
            }
        }
        return arr;
    }

        /**
     * Inicia el juego SilkRoad en modo consola.
     */
    public static void startGame() {
        Scanner sc = new Scanner(System.in);
        System.out.println("=== Bienvenido a SilkRoad ===");
        System.out.print("Ingrese la longitud de la ruta: ");
        int length = sc.nextInt();
        
        SilkRoad game = new SilkRoad(length);
        //game.makeVisible();//
        
        int option;
        do {
            System.out.println("\n=== MENÚ SILKROAD ===");
            System.out.println("1. Añadir tienda");
            System.out.println("2. Añadir robot");
            System.out.println("3. Mover robot");
            System.out.println("4. Ver profit total");
            System.out.println("5. Reiniciar");
            System.out.println("6. Mover todos los robots automáticamente");
            System.out.println("7. Ver estadísticas");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opción: ");
            option = sc.nextInt();
    
            switch (option) {
                case 1:
                    System.out.print("Ubicación de la tienda: ");
                    int locStore = sc.nextInt();
                    System.out.print("Cantidad de tenges: ");
                    int tenges = sc.nextInt();
                    game.placeStore(locStore, tenges);
                    break;
                case 2:
                    System.out.print("Ubicación del robot: ");
                    int locRobot = sc.nextInt();
                    game.placeRobot(locRobot);
                    break;
                case 3:
                    System.out.print("Ubicación inicial del robot: ");
                    int start = sc.nextInt();
                    System.out.print("Movimiento (positivo o negativo): ");
                    int move = sc.nextInt();
                    game.moveRobot(start, move);
                    break;
                case 4:
                    System.out.println("Profit actual: " + game.profit());
                    break;
                case 5:
                    game.reboot();
                    System.out.println("Sistema reiniciado.");
                    break;
                case 6:
                    game.moveRobots();
                    System.out.println("Robots movidos automáticamente.");
                    break;
                case 7:
                    System.out.println("Tiendas vaciadas:");
                    int[][] est = game.emptiedStores();
                    for (int[] e : est) {
                        System.out.println("Ubicación " + e[0] + " → " + e[1] + " veces.");
                    }
                    break;
                case 8:
                    System.out.println("Finalizando SilkRoad...");
                    break;
                default:
                    System.out.println("⚠️ Opción inválida.");
            }
    
        } while (option != 8);
    }

    public int marathonProfit() {
        int totalProfit = 0;
    
        // Copia las listas para no modificar las originales
        ArrayList<Store> remainingStores = new ArrayList<>(stores);
        ArrayList<Robot> availableRobots = new ArrayList<>(robots);
    
        // Asignar cada robot a la tienda que le da mayor ganancia
        for (Robot r : availableRobots) {
            Store bestStore = null;
            int bestGain = Integer.MIN_VALUE;
    
            for (Store s : remainingStores) {
                int distance = Math.abs(r.getLocation() - s.getLocation());
                int gain = s.getTenges() - distance;
    
                if (gain > bestGain) {
                    bestGain = gain;
                    bestStore = s;
                }
            }
    
            // Si hay una tienda que da ganancia positiva
            if (bestStore != null && bestGain > 0) {
                totalProfit += bestGain;
                moveRobot(r.getLocation(), bestStore.getLocation() - r.getLocation());
                bestStore.collect();
                remainingStores.remove(bestStore);
            }
        }
    
        System.out.println("Ganancia máxima del día: " + totalProfit);
        return totalProfit;
        }
    }




























