import static org.junit.Assert.*;
import org.junit.Test;

public class SilkRoadContestCTest {

    @Test
    public void testSolve() {
        SilkRoadContest contest = new SilkRoadContest();

        int[][] dias = {
            {100, 60, 80, 70, 120, 50}, // día 1 → 70
            {90, 40, 60, 60, 30, 20}   // día 2 → 50
        };

        int[] resultado = contest.solve(dias);
        assertArrayEquals(new int[]{70, 50}, resultado);
    }

    @Test
    public void testSimulate() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] dias = {
            {100, 60, 80, 70, 120, 50},
            {90, 40, 60, 60, 30, 20}
        };
        contest.simulate(dias, false);
    }
}
